CREATE DATABASE  IF NOT EXISTS `licnakarta` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `licnakarta`;
-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: licnakarta
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `documentrequest`
--

DROP TABLE IF EXISTS `documentrequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documentrequest` (
  `id` bigint NOT NULL,
  `JMBG` varchar(45) NOT NULL,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `imeMajke` varchar(45) NOT NULL,
  `prezimeMajke` varchar(45) NOT NULL,
  `prezimeOca` varchar(45) NOT NULL,
  `pol` varchar(45) NOT NULL,
  `datumRodjenja` varchar(45) NOT NULL,
  `nacionalnost` varchar(45) NOT NULL,
  `profesija` varchar(45) NOT NULL,
  `bracnoStanje` varchar(45) NOT NULL,
  `opstinaPrebivalista` varchar(45) NOT NULL,
  `ulicaPrebivalista` varchar(45) NOT NULL,
  `brojPrebivalista` varchar(45) NOT NULL,
  `imeOca` varchar(45) NOT NULL,
  `status` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documentrequest`
--

LOCK TABLES `documentrequest` WRITE;
/*!40000 ALTER TABLE `documentrequest` DISABLE KEYS */;
INSERT INTO `documentrequest` VALUES (173680000000,'2001999710194','Vladimir','siskin','Vesna','Siskin','Siskin','muski','20.01.1999','unesi nac','unesi profesiju','neozenje/neudata','opstina','ulica','broj','Predrag','Kreiran'),(173680000001,'2001999710194','Vladimir','siskin','Vesna','Siskin','Siskin','muski','1999-20-01','Srpsko','student','ozenje/udata','Zvezdara','Celopecka','12','Predrag','Kreiran'),(173680000002,'2001999710194','Vladimir','siskin','Vesna','Siskin','Siskin','muski','1999-20-01','Srpsko','student','ozenje/udata','Zvezdara','Celopecka','12','Predrag','proizveden'),(173680000003,'2001999710194','Vladimir','siskin','Vesna','Siskin','Siskin','muski','1999-20-01','Srpsko','student','ozenje/udata','Zvezdara','Celopecka','12','Predrag','proizveden'),(173680000004,'2001999710194','Nikola','siskin','Vesna','Siskin','Siskin','muski','1999-20-01','Srpsko','student','ozenje/udata','Zvezdara','Celopecka','12','Predrag','Kreiran'),(173680000005,'2001999710194','Marko','siskin','Vesna','Siskin','Siskin','muski','1999-20-01','Srpsko','student','ozenje/udata','Zvezdara','Celopecka','12','Predrag','U produkciji'),(173680000006,'unesi jmbg','Nikola','Tatomirovic','unesi ime','unesi prezime','unesi prezime','muski','1998-10-10','unesi nac','unesi profesiju','neozenje/neudata','opstina','ulica','broj','unesi ime','Kreiran'),(173680000007,'2001999710194','Nikola','Tatomirovic','Vesna','Siskin','Siskin','muski','1998-10-10','Srpsko','prof','ozenje/udata','Zvezdara','Celopecka','12','Predrag','U produkciji'),(173680000008,'unesi jmbg','Mirko','Milosevic','Vesna','Siskin','Siskin','muski','1998-11-11','Srpsko','profesija','razveden/a','Zvezdara','Celopecka','12','Predrag','Kreiran'),(173680000009,'2001999710194','Mirko','Milosevic','Vesna','Siskin','Siskin','muski','1998-11-11','Srpsko','profesija','razveden/a','Zvezdara','Celopecka','12','Predrag','Kreiran'),(173680000010,'2001999710194','Mirko','Milosevic','Vesna','Siskin','Siskin','muski','1998-11-11','Srpsko','profesija','ozenje/udata','Zvezdara','Celopecka','12','Predrag','Kreiran'),(173680000011,'2001999710194','Vladimir','Siskin','Vesna','Siskin','Siskin','muski','1999-10-10','Srpsko','profesija','ozenje/udata','Zvezdara','Celopecka','12','Predrag','U produkciji'),(173680000012,'2001999710194','Nikola','unesiprezime','unesiime','unesiprezime','unesiprezime','unesitepol','1999-10-10','unesnac','unesiprofesiju','razveden/a','opstina','ulica','broj','unesiime','U produkciji'),(173680000013,'unesjmbg','Vladimir','unesiprezime','unesiime','unesiprezime','unesiprezime','unesitepol','1997-10-11','unesinac','unesprofesiju','neozenje/neudata','opstina','ulica','broj','unesime','Kreiran'),(173680000014,'unesijmbg','unesiime11','unesiprezime','unesiime','unesi\\prezime','unesiprezime','unesitepol','1999-08-08','unesinac','unesiprofesiju','ozenje/udata','opstina','ulica','broj','unesiime','Kreiran'),(173680000015,'2001999710194','unesiime11','unesiprezime','unesiime','unesi\\prezime','unesiprezime','unesitepol','1999-10-10','unesinac','unesiprofesiju','ozenje/udata','opstina','ulica','broj','unesiime','U produkciji'),(173680000016,'1702998710194','Vukasin','Stankovic','Biljana','Stankovic','Stankovic','muski','1998-10-10','Srpsko','profesor','ozenje/udata','Zvezdara','ulica','broj','Dejan','urucen'),(173680000017,'1908001715194','Ana','Siskin','Vesna','Siskin','Siskin','zenski','2001-19-08','Srpsko','ucenik','ozenje/udata','Zvezdara','Celopecka','12','Predrag','proizveden'),(173680000018,'1009998710317','Luka','Simovic','Maja','Simovi','Simovici','muski','1998-10-09','Srbin','kamatas','neozenje/neudata','opstina','ulica','broj','Nebojsa','proizveden'),(173680000019,'2001999710194','Luka','Simovic','Vesna','Siskin','Siskin','muski','1998-10-09','Srpsko','profesor','neozenje/neudata','Zvezdara','Celopecka','13','Nebojsa','urucen'),(173680000020,'2001999710194','Nikoila','Momcilovic','unesime','unesiprezime','unesprezime','muskiu','1998-10-10','unesinac','unesi profesiju','neozenje/neudata','opstina','ulica','broj','unesime','proizveden');
/*!40000 ALTER TABLE `documentrequest` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-02-07 10:57:02
